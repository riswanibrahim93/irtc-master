<?php 

class Custom_model extends CI_Model{

    public function getUserByEmail($email)
    {
        $this->db->where('email', $email);
        return $this->db->get('users')->row();
    }
    
    public function getUserById($id)
    {
        $this->db->select([
            'users.id', 'users.nama_tim', 'users.nama_ketua', 'users.email', 'users.alamat',
            'kategori_lomba.nama_lomba', 'users.jumlah_anggota'
        ]);
        $this->db->where('users.id', $id);
        $this->db->from('users');
        $this->db->join('kategori_lomba', 'users.kategori_lomba_id = kategori_lomba.id');
        return $this->db->get();
    }

    public function cekUserLogin($email, $password)
    {
        $this->db->where('email', $email);
        $this->db->where('password', md5($password));
        return $this->db->get('users')->row();
    }

    public function getAnggota($id)
    {
        $this->db->where('user_id', $id);
        return $this->db->get('anggota_tim');
    }

    public function getDataPembayaran($id)
    {
        $this->db->where('user_id', $id);
        return $this->db->get('pembayaran')->row();
    }
}