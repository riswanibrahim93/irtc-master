@extends('welcome.partials.content')

@section('deskripsi')
<section id="kompetisi-section" style="min-height: 900px">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-kompetisi">
				<center><h1 class="h1-kompetisi">Line Follower</h1>
                <hr class="hr-kompetisi">
				</center>
				<div class="card">
                    <div class="card-body" style="padding: 10px 30px">
                        <ol>
                        <li>Peserta wajib mengisi formulir pendaftaran dengan data yang benar dan legal secara hukum di Website kegiatan.</li>
                        <li>Peserta yang tidak dapat memenuhi persyaratan pendaftaran hingga batas waktu yang telah ditentukan akan dinyatakan gugur.</li>
                        <li>Setiap peserta hanya dapat terdaftar dalam satu tim pada kategori perlombaan yang sama.</li>
                        <li>Setiap tim mengunggah proposal sesuai dengan tema yang tersedia ke Google Drive masing-masing, lalu mengirim link tersebut kepada panitia sampai batas yang telah ditentukan.</li>
                        <li>Tim yang lolos ke tahap kedua wajib merealisasikan karya sesuai proposal.</li>
                        <li>Setiap peserta yang lolos tahap kedua wajib membuat video teaser dan diunggah ke Youtube dengan durasi maksimal 5 menit, lalu mengirimkan link video tersebut ke panitia sebelum batas waktu yang ditentukan.</li>
                        <li>Tim yang lolos ke tahap grand final wajib mengikuti rangkaian acara final.</li>
                        <li>Tim yang tidak mengkonfirmasikan kehadiran akan didiskualifikasi.</li>
                        <li>Panitia berhak mencabut penghargaan dari tim, bila ditemukan kecurangan atau pelanggaran hukum atas karya yang dilombakan.</li>
                        <li>Petunjuk teknis dapat berubah sewaktu-waktu. Perubahan petunjuk teknis akan diinformasikan kepada peserta melalui media sosial Credia.ID.</li>
                    </ol>
					</div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection