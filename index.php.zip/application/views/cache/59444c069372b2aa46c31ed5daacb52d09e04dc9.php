<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12 grid-margin">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Biodata Team</h4>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <tbody>
                            <tr>
                                <td>Nama Team</td>
                                <td>:</td>
                                <td><?php echo e($user->nama_tim); ?></td>
                            </tr>
                            <tr>
                                <td>Ketua Tim</td>
                                <td>:</td>
                                <td><?php echo e($user->nama_ketua); ?></td>
                            </tr>
                            <tr>
                                <td>Email</td>
                                <td>:</td>
                                <td><?php echo e($user->email); ?></td>
                            </tr>
                            <tr>
                                <td>Alamat</td>
                                <td>:</td>
                                <td><?php echo e($user->alamat); ?></td>
                            </tr>
                            <tr>
                                <td>Kategori Lomba</td>
                                <td>:</td>
                                <td><?php echo e($user->nama_lomba); ?></td>
                            </tr>
                            
                        </tbody>
                    </table>
                    
                </div>
                
                <h4 class="card-title mt-3"> Anggota Tim </h4>
                <?php
                    $anggota_tim_inserted = count($anggota_tim);
                    $jumlah_anggota  = $user->jumlah_anggota;
                ?>
                <?php if($jumlah_anggota == $anggota_tim_inserted): ?>
                    <?php $__currentLoopData = $anggota_tim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anggota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="table-responsive">
                            <table  class="table table-hover mb-3">
                                <tr>
                                    <td>Nama Anggota <?php echo e($loop->iteration); ?></td>
                                    <td>:</td>
                                    <td><?php echo e($anggota->nama_anggota); ?></td>
                                </tr>
                                <tr>
                                    <td>Email Anggota <?php echo e($loop->iteration); ?></td>
                                    <td>:</td>
                                    <td><?php echo e($anggota->email); ?></td>
                                </tr>
                                <tr>
                                    <td>Nama Anggota <?php echo e($loop->iteration); ?></td>
                                    <td>:</td>
                                    <td><?php echo e($anggota->alamat); ?></td>
                                </tr>
                            </table>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    
                <?php else: ?>
                <?php echo form_open('dashboard'); ?>

                <?php echo validation_errors(); ?>

                        <div class="row">
                        <?php for($i = 1; $i <= $jumlah_anggota; $i++): ?>
                            <div class="col-md-6">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Nama Anggota <?php echo e($i); ?></label>
                                        <input type="text" class="form-control" name="nama_anggota[]">
                                    </div>

                                    <div class="form-group">
                                        <label>Email Anggota <?php echo e($i); ?></label>
                                        <input type="text" class="form-control" name="email_anggota[]">
                                    </div>
                                    
                                    <div class="form-group">
                                        <label>Alamat Anggota <?php echo e($i); ?></label>
                                        <input type="text" class="form-control" name="alamat_anggota[]">
                                    </div>
                                </div>
                            </div>
                        <?php endfor; ?>
                        <div class="col-md-12">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </div>
                        </div>
                    </div>
                    
                    <?php echo form_close(); ?>

                <?php endif; ?>
                
               
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>