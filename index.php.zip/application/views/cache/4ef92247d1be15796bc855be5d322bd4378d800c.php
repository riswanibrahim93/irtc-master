<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Credia.id | Dashboard</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="<?php echo e(base_url('server/vendors/iconfonts/mdi/css/materialdesignicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(base_url('server/vendors/css/vendor.bundle.base.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(base_url('server/css/datatables/jquery.datatables.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(base_url('server/css/datatables/button.css')); ?>">
    <!-- endinject -->
    <!-- inject:css -->
    <link rel="stylesheet" href="<?php echo e(base_url('server/css/style.css')); ?>">
    <!-- endinject -->
    <link rel="shortcut icon" href="<?php echo e(base_url('server/images/favicon.png')); ?>" />
</head>

<body>
    <div class="container-scroller">
        <!-- partial:partials/_navbar.html -->
        <?php echo $__env->make('user.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial:partials/_sidebar.html -->
            <?php echo $__env->make('user.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="page-header">
                        <h3 class="page-title">
                            <span class="page-title-icon bg-gradient-primary text-white mr-2">
                                <i class="mdi mdi-home"></i>
                            </span>
                            Selamat datang di credia.id
                        </h3>
                    </div>
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                <!-- content-wrapper ends -->
                <!-- partial:partials/_footer.html -->
                <?php echo $__env->make('user.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->

    <!-- plugins:js -->
    <script src="<?php echo e(base_url('server/vendors/js/vendor.bundle.base.js')); ?>"></script>
    <script src="<?php echo e(base_url('server/vendors/js/vendor.bundle.addons.js')); ?>"></script>
    <script src="<?php echo e(base_url('server/js/datatables/jquery.datatables.js')); ?>"></script>
    <script src="<?php echo e(base_url('server/js/datatables/button.datatables.js')); ?>"></script>
    <script src="<?php echo e(base_url('server/js/datatables/print.button.js')); ?>"></script>
    <!-- endinject -->
    <!-- Plugin js for this page-->
    <!-- End plugin js for this page-->
    <!-- inject:js -->
    
    <!-- endinject -->
    <!-- Custom js for this page-->
    <script src="<?php echo e(base_url('server/js/dashboard.js')); ?>"></script>
    <!-- End custom js for this page-->
</body>

</html>
