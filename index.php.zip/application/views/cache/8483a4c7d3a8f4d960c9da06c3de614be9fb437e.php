<?php $__env->startSection('content'); ?>
<?php
    $CI =& get_instance();
?>
<div class="row">
    <div class="col-12 grid-margin">
        <div class="card">
            <div class="card-body">
                <?php echo validation_errors(); ?>

                <?php echo form_open_multipart('pembayaran'); ?>

                <h4 class="card-title">Upload bukti pembayaran</h4>
                    <div class="form-group">
                        <input type="file" class="form-control" name="bukti_pembayaran">
                        <input type="hidden" name="user" value="<?php echo e($CI->session->userdata('id')); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Upload</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>